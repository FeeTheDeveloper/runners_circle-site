import type { Metadata } from "next";
import { Container, SectionHeading, Card, Button } from "@/components/ui/primitives";
import { FadeRise, StaggerReveal } from "@/components/ui/motion";

export const metadata: Metadata = {
  title: "In‑House Companies",
  description:
    "See how the Vet Gang collective uses Runners Circle OS to power every part of their businesses before deploying it to clients.",
  openGraph: {
    title: "In‑House Deployment",
    description:
      "Runners Circle OS is tested and proven across Vet Gang companies. Learn how our internal brands run on the same operating system we offer clients.",
    url: "/inhouse",
  },
};

const COMPANIES = [
  {
    name: "Vet Gang HQ",
    description:
      "The flagship operation where the OS was born. HQ uses the system to manage appointments, marketing, service pipelines and cross‑brand campaigns.",
  },
  {
    name: "Barbers & Blades",
    description:
      "A multi‑location barbershop brand leveraging AI appointment setting, review generation and seasonal promotions.",
  },
  {
    name: "Logistics Command",
    description:
      "A logistics startup coordinating dispatch, quotes and customer follow‑up through unified pipelines and automations.",
  },
  {
    name: "Consulting Ops",
    description:
      "Our internal consulting unit turns leads into clients with automated proposals, follow‑ups and content workflows.",
  },
];

export default function InHousePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0" />
        <div className="relative z-10 mx-auto max-w-4xl px-5 text-center">
          <FadeRise>
            <h1 className="font-heading text-4xl font-extrabold uppercase tracking-tight sm:text-5xl md:text-6xl lg:text-7xl text-brand-sand leading-[1.08]">
              In‑House&nbsp;Companies
            </h1>
          </FadeRise>
          <FadeRise delay={0.15}>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-brand-sand/70 sm:text-lg md:text-xl">
              We build Runners Circle OS for our own Vet Gang companies first. These internal deployments provide the proof, playbooks and templates that fuel our client success.
            </p>
          </FadeRise>
        </div>
      </section>

      {/* Companies Grid */}
      <section className="py-24 md:py-32 bg-brand-black">
        <Container>
          <SectionHeading
            title="Our Internal Lab"
            subtitle="Proof of concept and refinement across our own brands."
          />
          <StaggerReveal
            stagger={0.08}
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-2"
          >
            {COMPANIES.map(({ name, description }) => (
              <Card key={name}>
                <h3 className="font-heading text-lg font-bold uppercase tracking-wide text-brand-sand mb-3">
                  {name}
                </h3>
                <p className="text-sm leading-relaxed text-brand-sand/60">
                  {description}
                </p>
              </Card>
            ))}
          </StaggerReveal>
        </Container>
      </section>

      {/* CTA */}
      <section className="relative py-24 md:py-32 overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0 opacity-40" />
        <Container className="relative z-10 text-center">
          <FadeRise>
            <SectionHeading title="Want to Join the Circle?" />
          </FadeRise>
          <FadeRise delay={0.15}>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" href="/contact">
                Build Your System
              </Button>
              <Button variant="secondary" size="lg" href="/pricing">
                See Pricing
              </Button>
            </div>
          </FadeRise>
        </Container>
      </section>
    </>
  );
}