import type { Metadata } from "next";
import { Container, SectionHeading, Card, Button } from "@/components/ui/primitives";
import { FadeRise, StaggerReveal } from "@/components/ui/motion";

/* -------------------------------------------------------------------------- */
/*                              Runners Circle OS Page                        */
/* -------------------------------------------------------------------------- */

export const metadata: Metadata = {
  title: "Runners Circle OS",
  description:
    "AI CRM, marketing automation, and brand infrastructure for businesses built to scale.",
  openGraph: {
    title: "Runners Circle OS",
    description:
      "Runners Circle OS is the AI CRM and marketing operating system that powers lead capture, automation, content execution and performance insights.",
    url: "/os",
  },
};

const MODULES = [
  {
    title: "CRM Infrastructure",
    description:
      "Lead database, pipeline stages, opportunity tracking, contact tagging, scheduling, forms and follow‑up sequences.",
    bullets: [
      "Leads & Pipelines",
      "Contact Tagging",
      "Team Assignments",
      "Estimates & Invoices",
      "Scheduling & Booking",
      "SMS/Email Automation",
      "Forms & Surveys",
      "Reactivation Campaigns",
    ],
  },
  {
    title: "AI Marketing Automation",
    description:
      "Intelligent assistants for qualification, booking, follow‑up and content. Around‑the‑clock support that scales with your business.",
    bullets: [
      "AI Website Concierge",
      "AI Lead Qualifier",
      "AI Appointment Setter",
      "AI FAQ & Intake Assistants",
      "AI Sales Follow‑up",
      "AI Content Assistant",
      "AI Internal SOP Assistant",
    ],
  },
  {
    title: "Brand & Content Command",
    description:
      "Plan, produce and publish content that connects. Run campaigns and offers with templates built for your industry.",
    bullets: [
      "Content Calendar & Campaigns",
      "Ad & Landing Page Systems",
      "Offer & Messaging Frameworks",
      "Email & SMS Campaigns",
      "Lead Magnet Systems",
      "Seasonal Templates",
    ],
  },
  {
    title: "Performance Dashboard",
    description:
      "Real‑time insights into every stage of your revenue engine. Understand what’s working and where to optimize.",
    bullets: [
      "Leads by Source",
      "Booked Calls & Close Rate",
      "Campaign Conversion",
      "Reactivation Revenue",
      "Response & Follow‑up Times",
      "Revenue Pipeline by Brand",
    ],
  },
];

export default function RunnersCircleOSPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0" />
        <div className="relative z-10 mx-auto max-w-4xl px-5 text-center">
          <FadeRise>
            <h1 className="font-heading text-4xl font-extrabold uppercase tracking-tight sm:text-5xl md:text-6xl lg:text-7xl text-brand-sand leading-[1.08]">
              Runners&nbsp;Circle&nbsp;OS
            </h1>
          </FadeRise>
          <FadeRise delay={0.15}>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-brand-sand/70 sm:text-lg md:text-xl">
              The AI CRM and marketing operating system that captures leads,
              automates follow‑up, produces content and delivers actionable
              insights — proven in‑house across Vet Gang companies and deployed
              for brands nationwide.
            </p>
          </FadeRise>
          <FadeRise delay={0.3}>
            <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" href="/contact">
                Book a System Buildout
              </Button>
              <Button variant="secondary" size="lg" href="/pricing">
                View Pricing
              </Button>
            </div>
          </FadeRise>
        </div>
      </section>

      {/* Modules Section */}
      <section className="py-24 md:py-32 bg-brand-black">
        <Container>
          <SectionHeading
            title="What’s Inside"
            subtitle="Four integrated modules powering every stage of your revenue engine."
          />
          <StaggerReveal
            stagger={0.08}
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-2"
          >
            {MODULES.map(({ title, description, bullets }) => (
              <Card key={title}>
                <h3 className="font-heading text-lg font-bold uppercase tracking-wide text-brand-sand mb-3">
                  {title}
                </h3>
                <p className="text-sm leading-relaxed text-brand-sand/60 mb-5">
                  {description}
                </p>
                <ul className="space-y-2">
                  {bullets.map((b) => (
                    <li
                      key={b}
                      className="flex items-center gap-2 text-sm text-brand-sand/70"
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-brand-ember shrink-0" />
                      {b}
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </StaggerReveal>
        </Container>
      </section>

      {/* CTA Section */}
      <section className="relative py-24 md:py-32 overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0 opacity-40" />
        <Container className="relative z-10 text-center">
          <FadeRise>
            <SectionHeading title="Ready to Run Your Revenue Machine?" />
          </FadeRise>
          <FadeRise delay={0.15}>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" href="/contact">
                Launch Your AI CRM
              </Button>
              <Button variant="secondary" size="lg" href="/industries">
                Explore Use Cases
              </Button>
            </div>
          </FadeRise>
        </Container>
      </section>
    </>
  );
}