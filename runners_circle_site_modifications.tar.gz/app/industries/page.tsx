import type { Metadata } from "next";
import { Container, SectionHeading, Card, Button } from "@/components/ui/primitives";
import { FadeRise, StaggerReveal } from "@/components/ui/motion";

export const metadata: Metadata = {
  title: "Industries",
  description:
    "Discover how Runners Circle OS powers growth for service, beauty, consulting, healthcare, logistics and veteran‑owned businesses.",
  openGraph: {
    title: "Industries Served",
    description:
      "Explore use cases across barbers, salons, beauty, HVAC, home healthcare, consultants, law, tax, financial, logistics and veteran‑owned businesses.",
    url: "/industries",
  },
};

const INDUSTRIES = [
  {
    name: "Beauty & Wellness",
    description:
      "Salons, barbers and beauty businesses automate appointments, follow‑ups, reviews and rebooking.",
  },
  {
    name: "HVAC & Home Services",
    description:
      "Home service companies capture leads, qualify jobs, schedule visits and track jobs from estimate to invoice.",
  },
  {
    name: "Home Healthcare",
    description:
      "Healthcare providers manage intake, appointment setting, patient follow‑up and compliance workflows.",
  },
  {
    name: "Consultants & Agencies",
    description:
      "Consultants and agencies systematize lead qualification, proposals, project pipelines and recurring engagement.",
  },
  {
    name: "Legal, Tax & Financial",
    description:
      "Professional services firms streamline discovery, client onboarding, document requests and review cycles.",
  },
  {
    name: "Logistics & Transport",
    description:
      "Logistics and transport operators centralize inquiries, quotes, dispatch and customer communication.",
  },
  {
    name: "Veteran‑Owned",
    description:
      "Vet‑led businesses across industries leverage proven playbooks built by the Vet Gang collective.",
  },
];

export default function IndustriesPage() {
  return (
    <>
      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0" />
        <div className="relative z-10 mx-auto max-w-4xl px-5 text-center">
          <FadeRise>
            <h1 className="font-heading text-4xl font-extrabold uppercase tracking-tight sm:text-5xl md:text-6xl lg:text-7xl text-brand-sand leading-[1.08]">
              Industries&nbsp;We&nbsp;Serve
            </h1>
          </FadeRise>
          <FadeRise delay={0.15}>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-brand-sand/70 sm:text-lg md:text-xl">
              From barbers and beauty to HVAC, healthcare, consulting and logistics — Runners Circle OS is built to power any service business ready to scale.
            </p>
          </FadeRise>
        </div>
      </section>

      {/* Industries Grid */}
      <section className="py-24 md:py-32 bg-brand-black">
        <Container>
          <SectionHeading
            title="Use Cases"
            subtitle="Pre‑built templates and workflows for your market."
          />
          <StaggerReveal
            stagger={0.08}
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            {INDUSTRIES.map(({ name, description }) => (
              <Card key={name}>
                <h3 className="font-heading text-lg font-bold uppercase tracking-wide text-brand-sand mb-3">
                  {name}
                </h3>
                <p className="text-sm leading-relaxed text-brand-sand/60">
                  {description}
                </p>
              </Card>
            ))}
          </StaggerReveal>
        </Container>
      </section>

      {/* CTA */}
      <section className="relative py-24 md:py-32 overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0 opacity-40" />
        <Container className="relative z-10 text-center">
          <FadeRise>
            <SectionHeading title="Not Sure Where You Fit?" />
          </FadeRise>
          <FadeRise delay={0.15}>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" href="/contact">
                Get a Growth Audit
              </Button>
              <Button variant="secondary" size="lg" href="/os">
                Learn About the OS
              </Button>
            </div>
          </FadeRise>
        </Container>
      </section>
    </>
  );
}