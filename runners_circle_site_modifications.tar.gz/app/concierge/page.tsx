import type { Metadata } from "next";
import { Container, SectionHeading, Card, Button } from "@/components/ui/primitives";
import { FadeRise, StaggerReveal } from "@/components/ui/motion";

export const metadata: Metadata = {
  title: "AI Concierge",
  description:
    "Deploy a branded AI assistant on your website to qualify leads, answer questions, book appointments and support customers around the clock.",
  openGraph: {
    title: "AI Concierge",
    description:
      "Runners Circle AI Concierge greets visitors, qualifies leads, books calls and answers FAQs — giving your business a 24/7 front desk.",
    url: "/concierge",
  },
};

const FEATURES = [
  {
    title: "Website Assistant",
    body: "Instantly greet visitors, guide them through your offers and capture contact details for follow‑up.",
  },
  {
    title: "Lead Qualification",
    body: "Filter spam and low‑fit leads by collecting key details up front — service needed, location, budget and timeline.",
  },
  {
    title: "Appointment Setting",
    body: "Let your concierge schedule consultations or service visits directly into your calendar without human intervention.",
  },
  {
    title: "FAQ & Intake Support",
    body: "Answer common questions, gather intake information and route complex inquiries to your team.",
  },
  {
    title: "Sales Follow‑Up",
    body: "Send personalized follow‑ups via SMS or email, nurture leads and push them towards booking or purchase.",
  },
  {
    title: "Branded Experience",
    body: "Configured with your voice, design and workflows — no generic chatbot templates here.",
  },
];

export default function ConciergePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0" />
        <div className="relative z-10 mx-auto max-w-4xl px-5 text-center">
          <FadeRise>
            <h1 className="font-heading text-4xl font-extrabold uppercase tracking-tight sm:text-5xl md:text-6xl lg:text-7xl text-brand-sand leading-[1.08]">
              AI&nbsp;Concierge
            </h1>
          </FadeRise>
          <FadeRise delay={0.15}>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-brand-sand/70 sm:text-lg md:text-xl">
              Put a 24/7 AI assistant on your site that greets visitors, qualifies leads, books calls and answers every question — branded for your business.
            </p>
          </FadeRise>
          <FadeRise delay={0.3}>
            <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" href="/contact">
                Get Your AI Concierge
              </Button>
              <Button variant="secondary" size="lg" href="/pricing">
                See Packages
              </Button>
            </div>
          </FadeRise>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 md:py-32 bg-brand-black">
        <Container>
          <SectionHeading
            title="Concierge Features"
            subtitle="Automate your front desk without losing the human touch."
          />
          <StaggerReveal
            stagger={0.08}
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            {FEATURES.map(({ title, body }) => (
              <Card key={title}>
                <h3 className="font-heading text-lg font-bold uppercase tracking-wide text-brand-sand mb-3">
                  {title}
                </h3>
                <p className="text-sm leading-relaxed text-brand-sand/60">
                  {body}
                </p>
              </Card>
            ))}
          </StaggerReveal>
        </Container>
      </section>

      {/* CTA */}
      <section className="relative py-24 md:py-32 overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0 opacity-40" />
        <Container className="relative z-10 text-center">
          <FadeRise>
            <SectionHeading title="Add a Concierge to Your Business." />
          </FadeRise>
          <FadeRise delay={0.15}>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" href="/contact">
                Book Your Concierge
              </Button>
              <Button variant="secondary" size="lg" href="/os">
                Explore the OS
              </Button>
            </div>
          </FadeRise>
        </Container>
      </section>
    </>
  );
}