import type { Metadata } from "next";
import { Container, SectionHeading, Card, Button } from "@/components/ui/primitives";
import { FadeRise, StaggerReveal } from "@/components/ui/motion";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Transparent packages to launch and scale your AI CRM and marketing system. Choose the plan that fits your business.",
  openGraph: {
    title: "Pricing",
    description:
      "Flexible packages to set up your CRM, automation, content engine and dashboards — with options for multi‑brand deployments.",
    url: "/pricing",
  },
};

const PACKAGES = [
  {
    name: "Starter",
    tagline: "For small businesses getting started",
    bullets: [
      "CRM setup & pipeline",
      "Forms & calendar",
      "Missed‑call text back",
      "Basic nurture sequences",
    ],
  },
  {
    name: "Growth",
    tagline: "For brands ready to automate",
    bullets: [
      "Everything in Starter",
      "AI chatbot & qualification",
      "Email & SMS sequences",
      "Review engine",
      "Monthly reporting",
    ],
  },
  {
    name: "Authority",
    tagline: "For companies aiming for dominance",
    bullets: [
      "Everything in Growth",
      "Content & campaign engine",
      "Offer funnels & landing pages",
      "Reactivation campaigns",
      "AI concierge",
    ],
  },
  {
    name: "Multi‑Brand",
    tagline: "For enterprises & Vet Gang",
    bullets: [
      "Multiple business units",
      "Master dashboards",
      "Shared content operations",
      "Advanced automations",
      "Custom AI deployments",
    ],
  },
];

export default function PricingPage() {
  return (
    <>
      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0" />
        <div className="relative z-10 mx-auto max-w-4xl px-5 text-center">
          <FadeRise>
            <h1 className="font-heading text-4xl font-extrabold uppercase tracking-tight sm:text-5xl md:text-6xl lg:text-7xl text-brand-sand leading-[1.08]">
              Pricing&nbsp;&nbsp;Packages
            </h1>
          </FadeRise>
          <FadeRise delay={0.15}>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-brand-sand/70 sm:text-lg md:text-xl">
              Choose a plan that fits your growth stage — from getting started to running multiple brands on one command center.
            </p>
          </FadeRise>
        </div>
      </section>

      {/* Packages */}
      <section className="py-24 md:py-32 bg-brand-black">
        <Container>
          <SectionHeading
            title="Packages"
            subtitle="Every plan includes guidance and setup. Upgrade as you grow."
          />
          <StaggerReveal
            stagger={0.08}
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-4"
          >
            {PACKAGES.map(({ name, tagline, bullets }) => (
              <Card key={name} className="border-l-4 border-l-brand-ember">
                <h3 className="font-heading text-lg font-bold uppercase tracking-wide text-brand-sand mb-1">
                  {name}
                </h3>
                <p className="text-sm italic text-brand-sand/60 mb-4">{tagline}</p>
                <ul className="space-y-2 mb-6">
                  {bullets.map((b) => (
                    <li
                      key={b}
                      className="flex items-center gap-2 text-sm text-brand-sand/70"
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-brand-ember shrink-0" />
                      {b}
                    </li>
                  ))}
                </ul>
                <Button size="sm" href="/contact">
                  Get Started
                </Button>
              </Card>
            ))}
          </StaggerReveal>
        </Container>
      </section>

      {/* CTA */}
      <section className="relative py-24 md:py-32 overflow-hidden">
        <div className="gradient-hero-glow pointer-events-none absolute inset-0 z-0 opacity-40" />
        <Container className="relative z-10 text-center">
          <FadeRise>
            <SectionHeading title="Not Sure Which Plan?" />
          </FadeRise>
          <FadeRise delay={0.15}>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" href="/contact">
                Book a Free Consultation
              </Button>
              <Button variant="secondary" size="lg" href="/os">
                Explore the OS
              </Button>
            </div>
          </FadeRise>
        </Container>
      </section>
    </>
  );
}